angular.module('app.services', [])

.factory('httpInterceptor', ['$q',function($q) {
var regex = new RegExp('\.(html|json|css)$','i');
var isAsset = function(url){
    return regex.test(url);
};
return {
   
    'request': function(config) {
        
        if(!isAsset(config.url)){            
            config.url+= "?ts=" +  Date.now();     
        }
        return config;
    },

   
    'requestError': function(rejection) {
       
        return $q.reject(rejection);
    },




    'response': function(response) {
       
        return response;
    },

  
    'responseError': function(rejection) {
        return $q.reject(rejection);
    }
};
}])


.service('AuthenticationService', ["$http", "$state", function($http, $state){
	

	var self = this;
	
	self.checkToken = function(token){
		

		var data = {token: token};
		$http.post(" ", data).success(function(response){
			



				if (response === "unauthorized"){
				
					console.log("Logged out");
					$state.go("login")
			
				} 

				else {
				
					console.log("Logged In");
					return response;

				}
		
		}).error(function(error){
			$state.go("login")
			})
		
	}

}]);

