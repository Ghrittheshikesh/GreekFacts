angular.module('app.routes', [])

.config(function($stateProvider, $urlRouterProvider) {

  $stateProvider
    
      
        
    .state('testInfo', {
      url: '/testInfo',
      templateUrl: 'templates/testInfo.html',
      controller: 'testInfoCtrl'
    })
        
      
    
      
        
    .state('testSelection', {
      url: '/testSelection',
      templateUrl: 'templates/testSelection.html',
      controller: 'testSelectionCtrl'
    })
        
      
    
      
        
    .state('testDetails', {
      url: '/testDetails',
      templateUrl: 'templates/testDetails.html',
      controller: 'testDetailsCtrl'
    })
        
      
    
      
        
    .state('testInstructions', {
      url: '/testInstructions',
      templateUrl: 'templates/testInstructions.html',
      controller: 'testInstructionsCtrl'
    })
        
      
    
      
        
    .state('testPage', {
      url: '/testPage',
      cache: false,
      templateUrl: 'templates/testPage.html',
      controller: 'testPageCtrl'
    })
        
      
    
      
        
    .state('testMenu', {
      url: '/testMenu',
      templateUrl: 'templates/testMenu.html',
      controller: 'testMenuCtrl'
    })
        
      
    
      
        
    .state('testSummary', {
      url: '/testSummary',
      templateUrl: 'templates/testSummary.html',
      controller: 'testSummaryCtrl'
    })
        
      
    
      
        
    .state('bitwise', {
      url: '/bitwise',
      templateUrl: 'templates/bitwise.html',
      controller: 'bitwiseCtrl'
    })
     

     .state('thankyou', {
      url: '/thankyou',
      templateUrl: 'templates/thankyou.html',
     
    })   
      
    
      
        
    .state('login', {
      url: '/login',
      templateUrl: 'templates/login.html',
      controller: 'loginCtrl'
    })
        
      
    ;

  
  $urlRouterProvider.otherwise('/login');

});