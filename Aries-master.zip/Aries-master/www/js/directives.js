angular.module('app.directives', [])

//Button Switcher Directive
//Puropse to change ionic style of the buttons onClick
 

.directive('buttonSwitcher', [function(){

	 return {
    restrict : 'A',
    
    link : function(scope, elem, attrs) {
      
      var currentState = true;
      
      elem.on('click', function() {
        
        
        if(currentState === true) {
          console.log('It is Flagged');
          angular.element(elem).removeClass(attrs.onMark);
          angular.element(elem).addClass(attrs.offMark);
        }
        
        else {
          console.log('It is Answered');
          angular.element(elem).removeClass(attrs.offMark);
          angular.element(elem).addClass(attrs.onMark);
        }
        
        currentState = !currentState

      });
      
      
    }
  };

}]);

