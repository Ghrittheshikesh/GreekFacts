
angular.module('app.controllers', ['app.controllers'] )
//['ionic-material']


///////////////////////////////////////////////////////////


 //Page 1. Login Page Controller

.controller('loginCtrl', function($scope, $state, $http, RESOURCES) {

     //POST email and password 
    
    $scope.login = function() {
        
        var request = $http({
            method: "POST",
            url: RESOURCES.USERS_DOMAIN+'/ServerSideScripts/LoginScript.php',
            data: {
                email: $scope.lc.email,
                password: $scope.lc.pwd
            },
               headers: { 'Content-Type': 'application/x-www-form-urlencoded' } 
        });

        //Proceed to the Test Info Page on success
        
        request.success(function(data) {
         console.log(data);
         localStorage.setItem("token", JSON.stringify(data));
          ///Whats result?
           
           if (data == "proceed") {
           $state.go("testInfo"); 
            }

           })

        request.error(function(error){
            console.error(error);
        }); 
          

          /*
            if (data == "proceed") {

                $state.go('testInfo');
            }
            */
       
        }
  })// End of the Login Page Controller


/////////////////////////////////////////////////////////////

//Page 2. Test Info Controller

.controller('testInfoCtrl', function($scope, $state, $http, $rootScope) {

    //GET the test names in a dropDown variable

    $http.get("http://localhost/ServerSideScripts/TestInfo.php")
        .success(function(data) {
            
            $rootScope.testNames = data;

        });


    //POST test names in a dropDown variable and an enroll ID

    $scope.testInfo = function() {


        var request = $http({
            method: "POST",
            url: "http://localhost/ServerSideScripts/EnrolmentKey.php",
            data: {
              
              
                enroll: $scope.ti.enroll,
                  testName: $scope.ti.selectedAns.testName,

            },
            
        });
        
        //Proceed to Test Selection Page on success

        request.success(function(data) {
            if (data == "proceed") {
                $state.go('testSelection');
            }
        });
    }

}) //End of the Test Info Controller


///////////////////////////////////////////////////////////

//Page 3. Test Selection Controller

.controller('testSelectionCtrl', function($scope, $state, $http, $rootScope) {
        var appeared;
        //GET the test subjects in radioButton variable 
        //$rootScope.testSubjects to access testSubjects in the next page.

        $http.get("http://localhost/ServerSideScripts/TestSelection.php")
            .success(function(data) {
                $rootScope.testSubjects = data;
                var keys = Object.keys(data);
                $rootScope.len = keys.length;
                console.log($rootScope.len);
                $rootScope.length=$rootScope.len;
                
            });

        




        //POST test subjects in radioButton variable 

        $scope.testSelection = function() {

            var i=0; 
      
           $rootScope.selectedTest = $scope.ts.testSubjects;
           $rootScope.appeared= $rootScope.selectedTest;


            var temp = new Array();
            var temp1= new Array();
            temp1=temp.push($rootScope.appeared);
            console.log(temp);
            console.log(temp1);
            if(temp1==$rootScope.selectedTest){
        
            console.log(temp1);
            
       }
           
            var request = $http({
                method: "post",
                url: "http://localhost/ServerSideScripts/getQuestion.php",
                data: {
                    testSubject: $scope.ts.testSubjects
                },
                headers: {
                    'Content-Type': 'application/x-www-form-urlencoded'
                }

            });
           

 


            //Proceed to the Test Instructions Page on success

            request.success(function(data) {
                if (data == "proceed" ) {
                   
                    $state.go('testDetails');
                }

            });
        }


    })// End of the Test Selection Controller
   

///////////////////////////////////////////////////////////// 
 

//Page 4. Test Details Controller

.controller('testDetailsCtrl', function($scope, $state, $rootScope) {


$scope.go = function() {
        $state.go('testInstructions');
    };

return $rootScope.selectedTest


//$scope.testTime="60 mins";
//$scope.totalQuestions="25";

})//End of the Test Details Controller


//////////////////////////////////////////////////////////// 

//Page 5. Test Instructions Controller

.controller('testInstructionsCtrl', function($scope, $state) {

    $scope.goPage = function() {
       
        $state.go('testPage');
    };

})//End of the Test Instructions Controller


//////////////////////////////////////////////////////////// 

//Page 5. Popup Controller for the Test Instriction Page

.controller('testInstructionsPopup', function($scope, $ionicPopup, $state) {

    $scope.showConfirm = function() {
        var confirmPopup = $ionicPopup.confirm({
            title: 'Confirm',
            template: 'Are you sure you want to proceed?'
        });



        confirmPopup.then(function(res) {
            if (res) {
                console.log('You are sure');
                $state.go('testPage');


            } else {
                console.log('You are not sure');
            }
        });
    };

})// End of the Test Instriction Page's Popup Controller


//////////////////////////////////////////////////////////// 


//Page 6. Test Page Controller 

.controller('testPageCtrl', function($scope, $http, $state, $rootScope) {
document.querySelector('#time').value = "";


var fiveMinutes = 60 * 1,
    
    display = document.querySelector('#time');
    
    startTimer(fiveMinutes, display);

    function startTimer(duration, display) {
    var timer = duration, minutes, seconds;
    
    setInterval(function () {
        minutes = parseInt(timer / 60, 10)
        seconds = parseInt(timer % 60, 10);

        minutes = minutes < 10 ? "0" + minutes : minutes;
        seconds = seconds < 10 ? "0" + seconds : seconds;

        display.textContent = minutes + ":" + seconds;

        if (--timer < 0 ) {
            timer = duration;

        }
        if (display.textContent=='00:00' ){
  
        if($rootScope.length == 1){
           
           $state.go('thankyou');   
        }
            else{
        $state.go('bitwise');
         }

         
        
        }


        
        
    }, 1000);

}




  var getdata = function() {
    
    return $http.get("http://localhost/ServerSideScripts/FinalQuestionScript.php")
        .success(function(quizData) 
        {
            $scope.mquestions = quizData;

        });

}

getdata().then(function(quizData) {

    
    $scope.current = $scope.mquestions[0];
    
    var index;

    $scope.next = function(qno){
        
       
        var qno = $scope.getIndex($scope.current.index, 1);
    
       // var isAnswered= false;
       // var isFlagged = false;
       // var answers = undefined; 

       // if(isAnswered == true && isFlagged==true){

        var request = $http({
            method: "post",
            url: "http://localhost/ServerSideScripts/CorrectAns.php",
            data: {

                qid: $scope.current.qid,
                answer: $scope.ts.current.answers
               

                },
            headers: {
                'Content-Type': 'application/x-www-form-urlencoded'
            }
        });


                //}// End of IF

        $scope.current = $scope.mquestions[qno];
   
        $scope.qno = qno++;


        //Proceed to Test Page on success

        request.success(function(data) {
          console.log(data);
            if (data == "proceed") {
                $state.go('testPage');
            }
            });
    

    }
    
        $scope.previous = function(qno){
          
        var qno = $scope.getIndex($scope.current.index, -1);

       
        var request = $http({
            method: "post",
            url: "http://localhost/ServerSideScripts/CorrectAns.php",
            data: {

                qid: $scope.current.qid,
                answer: $scope.ts.current.answers
            },
            headers: {
                'Content-Type': 'application/x-www-form-urlencoded'
            }
        });


        $scope.current = $scope.mquestions[qno];
        
        $scope.qno = qno--;

        //Proceed to Test Page on success

        request.success(function(data) {
          console.log(data);
            if (data == "proceed") {
                $state.go('testPage');
                
            }
            });
    

    }
   
    $scope.getIndex = function(currentIndex, shift){
        var len = $scope.mquestions.length;
         var countdown = document.getElementById("00:00");
        return (((currentIndex + shift) + len) % len)
    }


}); //End of main function 


})//End of the Test Page Controller


///////////////////////////////////////////////////////


//Page 7. Test Menu Controller
//Purpose: To redirect to the pirticular question on the Test Page

.controller('testMenuCtrl', function($scope,$state, $ionicModal, $ionicActionSheet) {

$scope.jumpTo = function(id) {

$state.go('testPage');
 
};

})//End of the Test Menu Controller


/////////////////////////////////////////////////////////


//Page 8. Test Summary Page Controller

.controller('testSummaryCtrl', function($scope, $ionicPopup, $state, $rootScope, $http) {

var unansweredQuestions;

$http.get("http://localhost/ServerSideScripts/TestSummary.php")
        .success(function(data) {
            
       $scope.testSummary = data;
       return  $scope.unansweredQuestions= 25-$scope.testSummary.answeredQuestions;


        });



    $scope.showConfirm = function() {
        var confirmPopup = $ionicPopup.confirm({
            title: 'Confirm',
            template: 'Are you sure you want to proceed?'
        });



        confirmPopup.then(function(res) {
            if (res) {
                console.log('You are sure');
                
              

                
                if($rootScope.len==1){
                //logout    
                $state.go('thankyou');
                }else{
                $state.go('bitwise');
                $rootScope.length--;  
                }

        } else {
                
                console.log('You are not sure');
            }
        });
    };



})// End of the Test Summary Page Controller



///////////////////////////////////////////////////////////////

//Page 9. Bitwise Page Contoller
//Purpose to redirect to Test Selection Page for appearing the next test

.controller('bitwiseCtrl', function($scope,$state,$rootScope) {

var appearedSubject=[];

$rootScope.appearedSubject=$rootScope.appeared;


     $scope.goPage = function() {
      
        appearedSubject.push(" "+$rootScope.appeared);
        
        document.getElementById("demo").innerHTML = appearedSubject;
        $rootScope.len--;
        $state.go('testSelection');

    };


})//End of Bitwise Page Contoller



///////////////////////////////////////////////////////////////


.constant('RESOURCES', (function() {
  // Define your variable
  var resource = 'http://localhost';
  // Use the variable in your constants
  return {
    USERS_DOMAIN: resource,
    USERS_API: resource + '/ServerSideScripts',
   //LoginScript
    LoginScript: '/connection.php',
    TestInfo:'/TestInfo.php',
    EnrolmentKey:'/EnrolmentKey.php',
    TestSelection: '/TestSelection.php',
    getQuestion:'/getQuestion.php',
    FinalQuestionScript: 'FinalQuestionScript.php',
    CorrectAns: '/CorrectAns.php'
    
  }
})());
