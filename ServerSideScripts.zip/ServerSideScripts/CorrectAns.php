<?php
	if (isset($_SERVER['HTTP_ORIGIN'])) {
		header("Access-Control-Allow-Origin: {$_SERVER['HTTP_ORIGIN']}");
        header('Access-Control-Allow-Credentials: true');
        header('Access-Control-Max-Age: 86400');    
    }

    if ($_SERVER['REQUEST_METHOD'] == 'OPTIONS') {

        if (isset($_SERVER['HTTP_ACCESS_CONTROL_REQUEST_METHOD']))
            header("Access-Control-Allow-Methods: GET, POST, OPTIONS");         

        if (isset($_SERVER['HTTP_ACCESS_CONTROL_REQUEST_HEADERS']))
            header("Access-Control-Allow-Headers:        {$_SERVER['HTTP_ACCESS_CONTROL_REQUEST_HEADERS']}");

        exit(0);
    }


$server ="localhost";
$username ="root";
$passphrase = "root";
$dbname = "moodle";

$conn = mysqli_connect($server,$username,$passphrase,$dbname)or die("Error " . mysqli_error($conn));
;


//session_start();

$time = 0;

$postdata = file_get_contents("php://input");
	
		$request = json_decode($postdata);
        
    $questionID = $request->qId;
    $answerMarkd = $request->answer;
    $Flagged = $request->flag;
    $isAnswered = $request->isAnswered;
    $time =+ $request->ttime;  


//Complete later.



$q2 = "select answer from mdl_question_answers where question = '$questionId' and fraction = 1.0000000";
$r2 = mysqli_query($conn,$q2)or die("error fetching".mysqli_error($conn));

while($ro2 = mysqli_fetch_assoc($r2)){
    $rightAnswer = $ro2["answer"];
}



$sql = "Insert into mdl_question_attempts_mobile (qid,answerM,CorrectAns,Flagged,isAnswered,time) value ('$questionId','$answerMarkd','$rightAnswer','$Flagged','$isAnswered','$time')";

$resu = mysqli_query($conn,$sql)or die("error fetching".mysqli_error($conn));



//session_destroy();


mysqli_close($conn);


?>