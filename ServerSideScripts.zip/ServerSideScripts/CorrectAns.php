<?php

/*

    Here,
    The Answer marked by the candidate is sent using the POST method,
    along with the values of whether it is answered, flagged and also the time taken to answer that question.

    Answer marked is in "text" value, isAnswered is in "bool", Flagged again in "bool", time in "time".

    The question id is also sent along.

*/

#
#
# ServerDetails holds the details of the server including the script to solve CORS issue.
#
#    	

require_once('ServerDetails.php');

//Time variable initialised to store the time taken per question value.
$time = 0;

/*
    Data from the front end is sent using POST method.
    Values sent through are
    question ID, Answer Marked, Flagged, IsAnswered and Time(time to answer that question). 

*/

$postdata = file_get_contents("php://input");
	
		$request = json_decode($postdata);
        
    $questionID = $request->qId;
    $answerMarkd = $request->answer;
    $Flagged = $request->flag;
    $isAnswered = $request->isAnswered;
    $time =+ $request->ttime;  

//Query run to select the correct answer of the current question using the question ID provided.

$q2 = "select answer from mdl_question_answers where question = '$questionId' and fraction = 1.0000000";
$r2 = mysqli_query($conn,$q2)or die("error fetching".mysqli_error($conn));

while($ro2 = mysqli_fetch_assoc($r2)){
    $rightAnswer = $ro2["answer"];
}


//Query run to insert the above mentioned values including the correct answer which was fetched before and store it in the tabel mdl_question_attempts_mobile.

$sql = "Insert into mdl_question_attempts_mobile (qid,answerM,CorrectAns,Flagged,isAnswered,time) value ('$questionId','$answerMarkd','$rightAnswer','$Flagged','$isAnswered','$time')";

$resu = mysqli_query($conn,$sql)or die("error fetching".mysqli_error($conn));



//Closing the mysql connection to the database.


mysqli_close($conn);


?>