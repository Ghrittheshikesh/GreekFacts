<?php



// on submit click or time lapse store the total time taken for that category of quiz.

//try clubbing it with another script.


?>