<?php
if (isset($_SERVER['HTTP_ORIGIN'])) {
		header("Access-Control-Allow-Origin: {$_SERVER['HTTP_ORIGIN']}");
        header('Access-Control-Allow-Credentials: true');
        header('Access-Control-Max-Age: 86400');    
    }

    if ($_SERVER['REQUEST_METHOD'] == 'OPTIONS') {

        if (isset($_SERVER['HTTP_ACCESS_CONTROL_REQUEST_METHOD']))
            header("Access-Control-Allow-Methods: GET, POST, OPTIONS");         

        if (isset($_SERVER['HTTP_ACCESS_CONTROL_REQUEST_HEADERS']))
            header("Access-Control-Allow-Headers:        {$_SERVER['HTTP_ACCESS_CONTROL_REQUEST_HEADERS']}");

        exit(0);
    }


$server ="localhost";
$username ="root";
$passphrase = "root";
$dbname = "moodle";

$conn = mysqli_connect($server,$username,$passphrase,$dbname)or die("Error " . mysqli_error($conn));
;



$postdata = file_get_contents("php://input");
	
		$request = json_decode($postdata);

$testSubject=$request->testSubject;


$preSql = "Insert into mdl_Session_Data1 (SessD1,SessD2) values ('Null','$testSubject')";
$resu = mysqli_query($conn,$preSql) or die("Error in Selection").mysqli_error($conn);




if ($testSubject == !null) {
			echo "proceed" ;
		}


mysqli_close($conn);


?>