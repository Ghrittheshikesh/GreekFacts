<?php

/*

    Here,
    The Test Subject is fetched using POST method.

*/

#
#
# ServerDetails holds the details of the server including the script to solve CORS issue.
#
#    
require_once('ServerDetails.php'); 


//Data coming through POST method.
$postdata = file_get_contents("php://input");
	
		$request = json_decode($postdata);
        $testSubject=$request->testSubject;


//Query to store it in the DATABASE in the table mdl_Session_Data1.
$preSql = "Insert into mdl_Session_Data1 (SessD1,SessD2) values ('Null','$testSubject')";
$resu = mysqli_query($conn,$preSql) or die("Error in Selection").mysqli_error($conn);


//Checking not null and giving signal to goto to the next page.

if ($testSubject == !null) {
			echo "proceed" ;
		}

//Connection close.
mysqli_close($conn);


?>