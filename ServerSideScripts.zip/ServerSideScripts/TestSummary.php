<?php
if (isset($_SERVER['HTTP_ORIGIN'])) {                       		
        header("Access-Control-Allow-Origin: {$_SERVER['HTTP_ORIGIN']}");
        header('Access-Control-Allow-Credentials: true');
        header('Access-Control-Max-Age: 86400');    
    }

    if ($_SERVER['REQUEST_METHOD'] == 'OPTIONS') {

        if (isset($_SERVER['HTTP_ACCESS_CONTROL_REQUEST_METHOD']))
            header("Access-Control-Allow-Methods: GET, POST, OPTIONS");         

        if (isset($_SERVER['HTTP_ACCESS_CONTROL_REQUEST_HEADERS']))
            header("Access-Control-Allow-Headers:        {$_SERVER['HTTP_ACCESS_CONTROL_REQUEST_HEADERS']}");

        exit(0);
    }


$server ="localhost";
$username ="root";
$passphrase = "root";
$dbname = "moodle";

$conn = mysqli_connect($server,$username,$passphrase,$dbname)or die("Error " . mysqli_error($conn));
;


$anArray = array();

$query = "Select count(qid) as count where Flagged = 'true'";
$query1 = "Select count(qid) as count1 where isAnswered = 'true'";

$res = mysqli_query($conn,$query)or die("error fetching".mysqli_error($conn));
$res1 = mysqli_query($conn,$quer1)or die("error fetching".mysqli_error($conn));

while($ro = mysqli_fetch_assoc($res)){
    while($ro1 = mysqli_fetch_assoc($res1)){
        $anArray["answeredQuestions"] = $ro1["count1"];
        $anArray["flaggedQuestions"] = $ro["count"];
    }
}

echo json_encode($anArray);

mysqli_close($conn);




?>