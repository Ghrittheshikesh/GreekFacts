<?php
/*

Here, the count of the  questions flagged ,answered and unanswered are sent.


*/



#
#
# ServerDetails holds the details of the server including the script to solve CORS issue.
#
#    

require_once('ServerDetails.php');

$anArray = array();

//Query to fetch the count of isanswered and flagged.

$query = "Select count(qid) as count where Flagged = 'true'";
$query1 = "Select count(qid) as count1 where isAnswered = 'true'";

$res = mysqli_query($conn,$query)or die("error fetching".mysqli_error($conn));
$res1 = mysqli_query($conn,$quer1)or die("error fetching".mysqli_error($conn));

while($ro = mysqli_fetch_assoc($res)){
    while($ro1 = mysqli_fetch_assoc($res1)){
        $anArray["answeredQuestions"] = $ro1["count1"];
        $anArray["flaggedQuestions"] = $ro["count"];
    }
}

//Echo the data fetched to the GET Method.
echo json_encode($anArray);

//Conenction close.

mysqli_close($conn);




?>