<?php
		if (isset($_SERVER['HTTP_ORIGIN'])) {
		header("Access-Control-Allow-Origin: {$_SERVER['HTTP_ORIGIN']}");
        header('Access-Control-Allow-Credentials: true');
        header('Access-Control-Max-Age: 86400');    
    }

    if ($_SERVER['REQUEST_METHOD'] == 'OPTIONS') {

        if (isset($_SERVER['HTTP_ACCESS_CONTROL_REQUEST_METHOD']))
            header("Access-Control-Allow-Methods: GET, POST, OPTIONS");         

        if (isset($_SERVER['HTTP_ACCESS_CONTROL_REQUEST_HEADERS']))
            header("Access-Control-Allow-Headers:        {$_SERVER['HTTP_ACCESS_CONTROL_REQUEST_HEADERS']}");

        exit(0);
    }


$server ="localhost";
$username ="root";
$passphrase = "root";
$dbname = "moodle";

$conn = mysqli_connect($server,$username,$passphrase,$dbname)or die("Error " . mysqli_error($conn));
;



$PrepreSql = "Select count(*) as count from mdl_Session_Data1";
$resur = mysqli_query($conn,$PrepreSql) or die("Error in Selection").mysqli_error($conn);

while($ros = mysqli_fetch_assoc($resur)){
    $count = $ros['count'];
}

//$courseName = "NodeJs";

$preSql = "Select SessD2 from mdl_Session_Data1 where id ='$count'";
$resu = mysqli_query($conn,$preSql) or die("Error in Selection").mysqli_error($conn);

while($ro = mysqli_fetch_assoc($resu)){
    $courseName = $ro['SessD2']; 
}



//echo $courseName;
//fetch course id


$qid = array();

//according to the course id fetch the questions pertaining to that course.

$sql1 = "select id from mdl_question where name = '$courseName'";
$result1 = mysqli_query($conn,$sql1)or die("error fetching".mysqli_error($conn));

$count = 0;
while($row1 = mysqli_fetch_assoc($result1)){
	$qid = $row1["id"];
	$count++;
}

//echo $count;

//depending on the category, if 1 qno 123, if 6 qno 4,6, and if 8 qno 7,8

$empArray = array();

$a = 0;
$c=0;
for($q = 1;$q<=$count;$q++){
//for($q = 4;$q<7;$q+2){

$sql2 = "select id from mdl_question where name = '$courseName'";
$result100 = mysqli_query($conn,$sql2)or die("error fetching".mysqli_error($conn));

$count = 0;
while($row12 = mysqli_fetch_assoc($result100)){
	$a = $row12["id"];
    
    
$query1 = "SELECT id,questiontext FROM mdl_question where id= '$a' ";
$query2 = "SELECT answer FROM mdl_question_answers where question = '$a' ";
#$query3 = "SELECT answer FROM mdl_question_answers WHERE question='2',fraction='1.0000000'";

$result2 = mysqli_query($conn,$query1)or die("error fetching".mysqli_error($conn));
$result3 = mysqli_query($conn,$query2)or die("error fetching".mysqli_error($conn));
#$result4 = $conn->query($query3);

$questarray = array();
$answerArr[] = array();
while($row2=mysqli_fetch_assoc($result2)){
	$questarray["id"]=$row2["id"];
	$questarray["questionText"]=$row2["questiontext"]; 
    $questarray["answers"]=array();
	while($row3=mysqli_fetch_assoc($result3)){
		$answerArr["opt"]=$row3["answer"];
		array_push($questarray["answers"], $answerArr);
	}
    $questarray["index"]=$c;
    $c++;
}
array_push($empArray,$questarray);

}
}
echo json_encode($empArray);

$fp = fopen('Questions.json', 'w');
    fwrite($fp, json_encode($empArray));
    fclose($fp);



mysqli_close($conn);

?>