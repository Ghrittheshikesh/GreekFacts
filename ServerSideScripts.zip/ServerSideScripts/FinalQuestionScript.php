<?php

/*

    Here,
    The Questions with the answers are sent through via GET method to the front end.

*/


#
#
# ServerDetails holds the details of the server including the script to solve CORS issue.
#
#    
require_once('ServerDetails.php');


//Queries run to fetch the last entered data which is the testSubject in the table mdl_Session_Data1. 


//Fetches the Total Count.
$PrepreSql = "Select count(*) as count from mdl_Session_Data1";
$resur = mysqli_query($conn,$PrepreSql) or die("Error in Selection").mysqli_error($conn);

//Assigns the last entered data's value to the varaiable Count.
while($ros = mysqli_fetch_assoc($resur)){
    $count = $ros['count'];
}

//Using that Count varaible fetching the data entered last.
$preSql = "Select SessD2 from mdl_Session_Data1 where id ='$count'";
$resu = mysqli_query($conn,$preSql) or die("Error in Selection").mysqli_error($conn);

while($ro = mysqli_fetch_assoc($resu)){
    $courseName = $ro['SessD2']; 
}



//Now the Question and Options.


$qid = array();

//according to the course id fetch the questions pertaining to that course.



//Getting the total no. of questions pertaining to the SubjectName.
$sql1 = "select id from mdl_question where name = '$courseName'";
$result1 = mysqli_query($conn,$sql1)or die("error fetching".mysqli_error($conn));

$count = 0;
while($row1 = mysqli_fetch_assoc($result1)){
	$qid = $row1["id"];
	$count++;
}



//Using that Count fetching the Questions and the corresponding Options.
$empArray = array();

$a = 0;
$c=0;


for($q = 1;$q<=$count;$q++){

$sql2 = "select id from mdl_question where name = '$courseName'";
$result100 = mysqli_query($conn,$sql2)or die("error fetching".mysqli_error($conn));

$count = 0;
while($row12 = mysqli_fetch_assoc($result100)){
	$a = $row12["id"];
    
//Question Text is fetched.    
$query1 = "SELECT id,questiontext FROM mdl_question where id= '$a' ";

//Question's Options are fetched.
$query2 = "SELECT answer FROM mdl_question_answers where question = '$a' ";


//Queries are run.
$result2 = mysqli_query($conn,$query1)or die("error fetching".mysqli_error($conn));
$result3 = mysqli_query($conn,$query2)or die("error fetching".mysqli_error($conn));


//Wrapped into the json format and encoded in JSON.
$questarray = array();
$answerArr[] = array();
while($row2=mysqli_fetch_assoc($result2)){
	$questarray["id"]=$row2["id"];
	$questarray["questionText"]=$row2["questiontext"]; 
    $questarray["answers"]=array();
	while($row3=mysqli_fetch_assoc($result3)){
		$answerArr["opt"]=$row3["answer"];
		array_push($questarray["answers"], $answerArr);
	}
    $questarray["index"]=$c;
    $c++;
}
array_push($empArray,$questarray);

}
}

//echoed to the Front end using GET method.
echo json_encode($empArray);

$fp = fopen('Questions.json', 'w');
    fwrite($fp, json_encode($empArray));
    fclose($fp);


//Connection CLOSE.
mysqli_close($conn);

?>