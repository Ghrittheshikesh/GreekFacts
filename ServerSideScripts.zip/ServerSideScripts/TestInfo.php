<?php

/*
    Here,
    The Test Names are sent form the DAtabse using Get Method.


*/


#
#
# ServerDetails holds the details of the server including the script to solve CORS issue.
#
#    
require_once('ServerDetails.php');


//Quering the count of the total values in the table.
$preQ = "Select * from mdl_testInfo";
if($r =  mysqli_query($conn,$preQ)or die("error fetching".mysqli_error($conn))){
    $count = mysqli_num_rows($r);
}

$arra2 = array();


//Fetching them and formatiing in JSON.

for($i=1;$i<=$count;$i++){
$sqlQ = "Select Id,TestName from mdl_testInfo where Id = $i ";
$resu =  mysqli_query($conn,$sqlQ)or die("error fetching".mysqli_error($conn));

$arra1 = array();    
while($row = mysqli_fetch_assoc($resu)){
    
    $arra1["testName"]=$row["TestName"];
    $arra1["value"] = $row["Id"];
}
array_push($arra2,$arra1);
}


$fp = fopen('TestInfo.json', 'w');
    fwrite($fp, json_encode($arra2));
    fclose($fp);


//Echo to the GET method in JSON format.

echo json_encode($arra2);

//Connection Close.
mysqli_close($conn);


?>