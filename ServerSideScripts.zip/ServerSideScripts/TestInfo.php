<?php

if (isset($_SERVER['HTTP_ORIGIN'])) {                       		header("Access-Control-Allow-Origin: {$_SERVER['HTTP_ORIGIN']}");
        header('Access-Control-Allow-Credentials: true');
        header('Access-Control-Max-Age: 86400');    
    }

    if ($_SERVER['REQUEST_METHOD'] == 'OPTIONS') {

        if (isset($_SERVER['HTTP_ACCESS_CONTROL_REQUEST_METHOD']))
            header("Access-Control-Allow-Methods: GET, POST, OPTIONS");         

        if (isset($_SERVER['HTTP_ACCESS_CONTROL_REQUEST_HEADERS']))
            header("Access-Control-Allow-Headers:        {$_SERVER['HTTP_ACCESS_CONTROL_REQUEST_HEADERS']}");

        exit(0);
    }


$server ="localhost";
$username ="root";
$passphrase = "root";
$dbname = "moodle";

$conn = mysqli_connect($server,$username,$passphrase,$dbname)or die("Error " . mysqli_error($conn));
;



$preQ = "Select * from mdl_testInfo";
if($r =  mysqli_query($conn,$preQ)or die("error fetching".mysqli_error($conn))){
    $count = mysqli_num_rows($r);
}

$arra2 = array();

for($i=1;$i<=$count;$i++){
$sqlQ = "Select Id,TestName from mdl_testInfo where Id = $i ";
$resu =  mysqli_query($conn,$sqlQ)or die("error fetching".mysqli_error($conn));

$arra1 = array();    
while($row = mysqli_fetch_assoc($resu)){
    
    $arra1["testName"]=$row["TestName"];
    $arra1["value"] = $row["Id"];
}
array_push($arra2,$arra1);
}


$fp = fopen('TestInfo.json', 'w');
    fwrite($fp, json_encode($arra2));
    fclose($fp);

echo json_encode($arra2);


mysqli_close($conn);


?>