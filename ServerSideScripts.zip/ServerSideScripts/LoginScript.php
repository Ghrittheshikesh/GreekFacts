<?php
		if (isset($_SERVER['HTTP_ORIGIN'])) {
		header("Access-Control-Allow-Origin: {$_SERVER['HTTP_ORIGIN']}");
        header('Access-Control-Allow-Credentials: true');
        header('Access-Control-Max-Age: 86400');    
    }

    if ($_SERVER['REQUEST_METHOD'] == 'OPTIONS') {

        if (isset($_SERVER['HTTP_ACCESS_CONTROL_REQUEST_METHOD']))
            header("Access-Control-Allow-Methods: GET, POST, OPTIONS");         

        if (isset($_SERVER['HTTP_ACCESS_CONTROL_REQUEST_HEADERS']))
            header("Access-Control-Allow-Headers:        {$_SERVER['HTTP_ACCESS_CONTROL_REQUEST_HEADERS']}");

        exit(0);
    }


$server ="localhost";
$username ="root";
$passphrase = "root";
$dbname = "moodle";

$conn = mysqli_connect($server,$username,$passphrase,$dbname)or die("Error " . mysqli_error($conn));
;


$postdata = file_get_contents("php://input");
	
		$request = json_decode($postdata);
		$email = $request->email;
		$passwd = $request->password;




//$password = "Admin123";
$fendpw= md5($passwd);
//echo $fendpw;
//$email = "danny.jo@gmail.com";

$sql = "select password from mdl_user  where email='$email'";

$result =mysqli_query($conn,$sql) or die ("Error in selecting".mysqli_error($conn));

while($row =mysqli_fetch_assoc($result))
{
	if($row["password"] == $fendpw ){
	echo "proceed" ;
    }
    //echo $row["password"];
}


//echo $emparray["password"];






//the above code snippet is commented because there is some issue due to which it isnt comparing the passwords.


/*echo json_encode($emparray);
$fp = fopen('LogDetail.json', 'w');
    fwrite($fp, json_encode($emparray));
    fclose($fp);
*/

//echo json_encode($data);



mysqli_close($conn);

?>