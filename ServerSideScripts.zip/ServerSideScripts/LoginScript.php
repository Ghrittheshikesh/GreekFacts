<?php

/*
    Here, 
    $email -> Value "email" entered by the user is stored.
    $passwd -> Value "password" entered by the user is stored.

    Password is checked against the password value stored in the Database by the admin
    using email as a parameter to fetch it.

*/


#
#
# ServerDetails holds the details of the server including the script to solve CORS issue.
#
#    
require_once('ServerDetails.php');


//   Data from the front end received through "POST" method.

$postdata = file_get_contents("php://input");
	
		$request = json_decode($postdata);
		$email = $request->email;
		$passwd = $request->password;


//Password being hashed with MD5 algorithm.
$fendpw= md5($passwd);



//Query for retrieving the password from the Database using email as the parameter to single out the required value.
$sql = "select password from mdl_user  where email='$email'";

//Query run.
$result =mysqli_query($conn,$sql) or die ("Error in selecting".mysqli_error($conn));


//Fetching of values in the form of an array.
while($row =mysqli_fetch_assoc($result))
{
	if($row["password"] == $fendpw ){
	echo "proceed" ;
    }
}


//Closing mysql connection.
mysqli_close($conn);

?>