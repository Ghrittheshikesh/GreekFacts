<?php

require_once("serverDetails.php");


#from the front side you'll get the tome start time end and the question number.try clubbing this with the response of the question.

//create a table in the existing db.
//and store the timestart and time end of that particular question. with usage id.


#$id
#$usageid
#$categid
#$questionid
#timeStart
#timeEnd

#you'll get the above ts and te with id catid and qid from the front end

$sql = "Insert into mdl_time_taken (id,usageid,questionid,cateid,timeStart,timeEnd) values ($id,$usageid,$questionid,$categid,$timestart,$timeEnd)";

$result = mysqli_query($conn,$sql);

#while and if statement for getting some function done.

?>