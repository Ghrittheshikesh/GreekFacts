<?php
//session_start();	

if (isset($_SERVER['HTTP_ORIGIN'])) {
		header("Access-Control-Allow-Origin: {$_SERVER['HTTP_ORIGIN']}");
        header('Access-Control-Allow-Credentials: true');
        header('Access-Control-Max-Age: 86400');    
    }

    if ($_SERVER['REQUEST_METHOD'] == 'OPTIONS') {

        if (isset($_SERVER['HTTP_ACCESS_CONTROL_REQUEST_METHOD']))
            header("Access-Control-Allow-Methods: GET, POST, OPTIONS");         

        if (isset($_SERVER['HTTP_ACCESS_CONTROL_REQUEST_HEADERS']))
            header("Access-Control-Allow-Headers:        {$_SERVER['HTTP_ACCESS_CONTROL_REQUEST_HEADERS']}");

        exit(0);
    }


$server ="localhost";
$username ="root";
$passphrase = "root";
$dbname = "moodle";

$conn = mysqli_connect($server,$username,$passphrase,$dbname)or die("Error " . mysqli_error($conn));
;



$postdata = file_get_contents("php://input");
	
		$request = json_decode($postdata);
	
	   $enroll=$request->enroll;
	$testName =$request->testName;

//$testName = "BitWise33";


$preSql = "Insert into mdl_session_data (Session,SessD1,SessD2) values ('$enroll','$testName','NULL')";
$resu = mysqli_query($conn,$preSql) or die("Error in Selection").mysqli_error($conn);

//echo $_session['testName'];

/*$fp = fopen('Enrol.json', 'w');
    fwrite($fp, json_encode($testName));
    fwrite($fp, json_encode($enroll));
    fclose($fp);
    */

if ($testName == !null && $enroll == !null) {
			echo "proceed" ;
           // echo $testName;
		}



mysqli_close($conn);

// Drop and create it at every time 

?>