<?php


/*

    Here,
    The Testname and Enrolment Key is sent via POST method.

*/



#
#
# ServerDetails holds the details of the server including the script to solve CORS issue.
#
#    

require_once('ServerDetails.php');

/*
    Enrollment Key and TestName is sent through.
*/

$postdata = file_get_contents("php://input");
	
		$request = json_decode($postdata);
	
	   $enroll=$request->enroll;
	$testName =$request->testName;


//Query run to insert into the table mdl_session_data as the new entry.

$preSql = "Insert into mdl_session_data (Session,SessD1,SessD2) values ('$enroll','$testName','NULL')";
$resu = mysqli_query($conn,$preSql) or die("Error in Selection").mysqli_error($conn);


//Checking whether the varaibles arent null and giving the signal to proceed. 
if ($testName == !null && $enroll == !null) {
			echo "proceed" ;
		}


//CLosing the connection
mysqli_close($conn);


?>