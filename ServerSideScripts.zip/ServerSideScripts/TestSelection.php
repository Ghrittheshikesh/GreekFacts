<?php

/*

Here,
The test Subjects are sent through GET method based on the TestName.

*/



#
#
# ServerDetails holds the details of the server including the script to solve CORS issue.
#
#    
require_once('ServerDetails.php');



//Query to select the total count and assigning it to the cariable Count.

$PrepreSql = "Select count(*) as count from mdl_session_data";
$resur = mysqli_query($conn,$PrepreSql) or die("Error in Selection").mysqli_error($conn);

while($ros = mysqli_fetch_assoc($resur)){
    $count = $ros['count'];
}


//Selecting the last entered data.

$preSql = "Select SessD1 from mdl_session_data where id ='$count'";
$resu = mysqli_query($conn,$preSql) or die("Error in Selection").mysqli_error($conn);

while($ro = mysqli_fetch_assoc($resu)){
    $testName = $ro['SessD1']; 
}



//Query to slect the testSubjects based on the testName fetched in the last query.
$q = "Select Value from mdl_test_Subjects where TestName = '$testName' ";
$resuy = mysqli_query($conn,$q) or die ("Error in selecting".mysqli_error($conn));

//taking the count of the total no. of testSubjects under the same testName.
$count = mysqli_num_rows($resuy);


$arrey = array();



//Query to get the testSubjects form the table. and format them in JSON.
for($i=1;$i<=$count;$i++){
$sqlq = "Select Value,TestSubject from mdl_test_Subjects where TestName = '$testName' and Value = '$i' ";

$ret = mysqli_query($conn,$sqlq) or die ("Error in selecting".mysqli_error($conn));

    
$arriy = array();    
while($rou = mysqli_fetch_assoc($ret)){
    $arriy["subjectName"]=$rou["TestSubject"];
    $arriy["value"]=$rou["Value"];
}    
array_push($arrey,$arriy);
}

$fp = fopen('TestSelect.json', 'w');
    fwrite($fp, json_encode($arrey));
    fclose($fp);


//Echo them in the JSON format to the GET method.
echo json_encode($arrey);


//Connection CLose.
mysqli_close($conn);



?>