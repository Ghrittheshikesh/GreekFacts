<?php
//session_start();

if (isset($_SERVER['HTTP_ORIGIN'])) {                       		
        header("Access-Control-Allow-Origin: {$_SERVER['HTTP_ORIGIN']}");
        header('Access-Control-Allow-Credentials: true');
        header('Access-Control-Max-Age: 86400');    
    }

    if ($_SERVER['REQUEST_METHOD'] == 'OPTIONS') {

        if (isset($_SERVER['HTTP_ACCESS_CONTROL_REQUEST_METHOD']))
            header("Access-Control-Allow-Methods: GET, POST, OPTIONS");         

        if (isset($_SERVER['HTTP_ACCESS_CONTROL_REQUEST_HEADERS']))
            header("Access-Control-Allow-Headers:        {$_SERVER['HTTP_ACCESS_CONTROL_REQUEST_HEADERS']}");

        exit(0);
    }


$server ="localhost";
$username ="root";
$passphrase = "root";
$dbname = "moodle";

$conn = mysqli_connect($server,$username,$passphrase,$dbname)or die("Error " . mysqli_error($conn));
;

//require_once('EnrolmentKey.php');

//$testName = "BitWise33";

$PrepreSql = "Select count(*) as count from mdl_session_data";
$resur = mysqli_query($conn,$PrepreSql) or die("Error in Selection").mysqli_error($conn);

while($ros = mysqli_fetch_assoc($resur)){
    $count = $ros['count'];
}

//echo $count;


$preSql = "Select SessD1 from mdl_session_data where id ='$count'";
$resu = mysqli_query($conn,$preSql) or die("Error in Selection").mysqli_error($conn);

while($ro = mysqli_fetch_assoc($resu)){
    $testName = $ro['SessD1']; 
}

//echo $testName;

//$testName = $_SESSION['testName'];
//get These two from db or another php script.    
// get test name and enrolkey
//and accordingly have it send the test names in the json form.
//require_once('EnrolmentKey.php');

//echo $testName;

$q = "Select Value from mdl_test_Subjects where TestName = '$testName' ";
$resuy = mysqli_query($conn,$q) or die ("Error in selecting".mysqli_error($conn));

$count = mysqli_num_rows($resuy);
//echo $count;

$arrey = array();

for($i=1;$i<=$count;$i++){
$sqlq = "Select Value,TestSubject from mdl_test_Subjects where TestName = '$testName' and Value = '$i' ";

$ret = mysqli_query($conn,$sqlq) or die ("Error in selecting".mysqli_error($conn));

    
$arriy = array();    
while($rou = mysqli_fetch_assoc($ret)){
    $arriy["subjectName"]=$rou["TestSubject"];
    $arriy["value"]=$rou["Value"];
}    
array_push($arrey,$arriy);
}

$fp = fopen('TestSelect.json', 'w');
    fwrite($fp, json_encode($arrey));
    fclose($fp);

echo json_encode($arrey);


mysqli_close($conn);



?>